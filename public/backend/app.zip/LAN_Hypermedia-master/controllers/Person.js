'use strict';

var utils = require('../utils/writer.js');
var PersonService = require('../service/PersonService');

module.exports.peopleGET = function peopleGET (req, res, next) {
  var limit = req.swagger.params['limit'].value;
  var offset = req.swagger.params['offset'].value;
  PersonService.peopleGET(limit,offset)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.personIdGET = function personIdGET (req, res, next) {
  var id = req.swagger.params['id'].value;
  PersonService.personIdGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.personPOST = function personPOST (req, res, next) {
  var person = req.swagger.params['person'].value;
  PersonService.personPOST(person)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
